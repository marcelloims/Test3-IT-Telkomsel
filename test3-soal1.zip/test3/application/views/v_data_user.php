<!DOCTYPE html>
<html>

<head>
    <?php $this->load->view('_templates_admin/header'); ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Navbar -->
        <?php $this->load->view('_templates_admin/navbar'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view('_templates_admin/sidebar'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Data User</h1>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container">
                    <table id="example1" class="table table-hover">
                        <thead>
                            <tr align="center">
                                <th>No</th>
                                <th>ID</th>
                                <th>Email</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($datalist->data as $value) :
                            ?>
                                <tr>
                                    <td align="center"><?= $no++ ?></td>
                                    <td align="center"><?= $value->id ?></td>
                                    <td><?= $value->email ?></td>
                                    <td><?= $value->first_name ?></td>
                                    <td><?= $value->last_name ?></td>
                                    <td align="center"><a href="#form" data-toggle="modal" class="btn btn-sm btn-info" onclick="submit(<?php echo  $value->id ?>)"><i class="fa fa-info-circle"> Detail</i></a></td>
                                </tr>
                            <?php endforeach;  ?>
                        </tbody>
                    </table>

                    <div class="modal fade" id="form" role="dialog">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h1>Detail User</h1>
                                </div>

                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <img src="" id="image" class="card-img-top">
                                        </div>
                                        <div class="col-md-8">
                                            <table class="table">
                                                <tr>
                                                    <td width="200px">ID</td>
                                                    <td>
                                                        <p id="id"></p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td width="200px">Email</td>
                                                    <td>
                                                        <p id="email"></p>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td width="200px">First Name</td>
                                                    <td>
                                                        <p id="first_name"></p>
                                                    <td>
                                                </tr>
                                                <tr>
                                                    <td width="200px">Last Name</td>
                                                    <td>
                                                        <p id="last_name"></p>
                                                    </td>
                                                </tr>
                                            </table>
                                            <button type="button" data-dismiss="modal" class="btn btn-sm btn-danger mb-3 mr-3 float-right">Kembali</button>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Main content -->
        </div>


        <footer class="main-footer">
            <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
            All rights reserved.
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b> 3.0.5
            </div>
        </footer>

        <!-- Control Sidebar -->
        <?php $this->load->view('_templates_admin/control-sidebar') ?>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <?php $this->load->view('_templates_admin/js'); ?>
    <script type="text/javascript">
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "autoWidth": false,
            });
        });

        function submit(x) {
            $.ajax({
                type: 'GET',
                data: 'id=' + x,
                url: 'https://reqres.in/api/users/' + x,
                dataType: 'json',
                success: function(detail) {
                    document.getElementById('id').innerHTML = detail.data.id;
                    document.getElementById('email').innerHTML = detail.data.email;
                    document.getElementById('first_name').innerHTML = detail.data.first_name;
                    document.getElementById('last_name').innerHTML = detail.data.last_name;
                    document.getElementById('image').src = detail.data.avatar;
                }
            });
        }
    </script>
    <!-- jQuery -->
</body>

</html>