<?php

class C_auth extends CI_Controller
{
    public function login()
    {
        $this->form_validation->set_rules('email', 'Email', 'required', ['required' => "Email TIDAK BOLEH KOSONG"]);
        $this->form_validation->set_rules('password', 'Password', 'required', ['required' => "Password TIDAK BOLEH KOSONG"]);

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('v_form_login');
        } else {
            $auth = $this->Model_admin->cek_login();

            if ($auth == FALSE) {
                $this->session->set_flashdata('pesan', '
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>Login Gagal</strong> Email atau Password Salah!.
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                ');
                redirect('c_auth/login');
            } else {

                $this->session->set_userdata('nama', $auth->nama);
                $this->session->set_userdata('email', $auth->email);
                $this->session->set_userdata('role_id', $auth->role_id);

                switch ($auth->role_id) {
                    case '1':
                        redirect('c_admin/dashboard');
                        break;

                    default:
                        break;
                }
            }
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('c_auth/login');
    }

    public function register()
    {
        $this->load->view('v_register');
    }

    public function daftar()
    {
        $nama = $this->input->post('nama');
        $email = $this->input->post('email');
        $password = $this->input->post('password');

        $data = [
            'nama' => $nama,
            'email' => $email,
            'password' => $password,
            'role_id' => 1
        ];

        $this->Model_admin->daftar($data, 'tb_users');
        redirect('c_auth/login');
    }
}
