<?php

class Model_admin extends CI_Model
{
    public function daftar($data, $table)
    {
        $this->db->insert($table, $data);
    }

    public function cek_login()
    {
        $email      = set_value('email');
        $password   = set_value('password');

        $result = $this->db->where('email', $email)
            ->where('password', $password)
            ->limit(1)
            ->get('tb_users');

        if ($result->num_rows() > 0) {
            return $result->row();
        } else {
            return array();
        }
    }

    public function detail_user($where, $table)
    {
        return $this->db->get_where($table, $where);
    }
}
