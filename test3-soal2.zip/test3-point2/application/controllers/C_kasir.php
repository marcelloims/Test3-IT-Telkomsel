<?php

class C_kasir extends CI_Controller
{
    public function dashboard()
    {
        $urlC = 'https://api-test.godig1tal.com/customer/all_customer';
        $get_urlC = file_get_contents($urlC);

        $customer = json_decode($get_urlC);


        $urlP = 'https://api-test.godig1tal.com/product/all_product';
        $get_urlP = file_get_contents($urlP);

        $product = json_decode($get_urlP);


        $urlR = 'https://api-test.godig1tal.com/order/sales_region_yearly';
        $get_urlR = file_get_contents($urlR);

        $region = json_decode($get_urlR);

        $urlO = 'https://api-test.godig1tal.com/order/all_order';
        $get_urlO = file_get_contents($urlO);

        $order = json_decode($get_urlO);


        $urlW = 'https://api-test.godig1tal.com/order/worst_10_product';
        $get_urlW = file_get_contents($urlW);

        $worst = json_decode($get_urlW);


        $urlT = 'https://api-test.godig1tal.com/order/top_10_product';
        $get_urlT = file_get_contents($urlT);

        $top = json_decode($get_urlT);


        $urlB = 'https://api-test.godig1tal.com/order/customer_ot_year';
        $get_urlB = file_get_contents($urlB);

        $buyer = json_decode($get_urlB);



        // $jumlah['jumlah_user'] = count($data->data);
        $data['region'] = count($region->data);
        $data['product'] = count($product->data);
        $data['customer'] = count($customer->data);
        $data['order'] = count($order->data);
        $data['worst'] = $worst->data;
        $data['top'] = $top->data;
        $data['buyer'] = $buyer->data;

        $this->load->view('v_dashboard', $data);
    }

    public function transaksi()
    {
        $urlC = 'https://api-test.godig1tal.com/customer/all_customer';
        $get_urlC = file_get_contents($urlC);

        $customer = json_decode($get_urlC);


        $urlP = 'https://api-test.godig1tal.com/product/all_product';
        $get_urlP = file_get_contents($urlP);

        $product = json_decode($get_urlP);


        $urlR = 'https://api-test.godig1tal.com/order/sales_region_yearly';
        $get_urlR = file_get_contents($urlR);

        $region = json_decode($get_urlR);


        $data['region'] = $region;
        $data['product'] = $product;
        $data['customer'] = $customer;



        $this->load->view('v_transaksi', $data);
    }


    public function tanggal_daftar_order()
    {
        $data['region'] = ['Central', 'West', 'South', 'East'];
        $this->load->view('v_tanggal_order', $data);
    }


    public function daftar_customer()
    {
        $url = 'https://api-test.godig1tal.com/customer/all_customer';
        $get_url = file_get_contents($url);

        $customer = json_decode($get_url);

        $data['customer'] = $customer;

        $this->load->view('v_daftar_customer', $data);
    }

    public function daftar_product()
    {
        $url = 'https://api-test.godig1tal.com/product/all_product';
        $get_url = file_get_contents($url);

        $product = json_decode($get_url);

        $data['product'] = $product;

        $this->load->view('v_daftar_product', $data);
    }

    public function daftar_order()
    {
        $url = 'https://api-test.godig1tal.com/order/all_order';
        $get_url = file_get_contents($url);

        $orders = json_decode($get_url);

        $data['orders'] = $orders;

        $this->load->view('v_daftar_orders', $data);
    }
}
