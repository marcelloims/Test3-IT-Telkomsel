<!DOCTYPE html>
<html>

<head>
    <?php $this->load->view('_templates_kasir/header'); ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Navbar -->
        <?php $this->load->view('_templates_kasir/navbar'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view('_templates_kasir/sidebar'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Transaksi</h1>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <form action="#" method="POST">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label>Order ID</label>
                                <?php
                                $no = 100001;
                                for ($i = 1; $i < 0; $no++)
                                ?>
                                <input type="text" class="form-control" id="order_id" name="order_id" value="US-<?= date('Y') ?>-<?= $no; ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Customer Name</label>
                                <select name="customer_name" id="customer_name" class="form-control">
                                    <?php foreach ($customer->data as $cus) : ?>
                                        <option value="<?= $cus->customer_name ?>"><?= $cus->customer_name ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Product Name</label>
                            <select name="product_name" id="product_name" class="form-control">
                                <?php foreach ($product->data as $pro) : ?>
                                    <option value="<?= $pro->product_name ?>"><?= $pro->product_name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-2">
                                <label>Date</label>
                                <input type="date" class="form-control" id="date" name="date">
                            </div>
                            <div class="form-group col-md-2 ">
                                <label>Sales</label>
                                <input type="text" class="form-control" id="sales" name="sales">
                            </div>
                            <div class="form-group col-md-2">
                                <label>Region</label>
                                <select name="region" id="region" class="form-control">
                                    <?php foreach ($region->data as $reg) : ?>
                                        <option value="<?= $reg->region ?>"><?= $reg->region ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-2 mt-4">
                                <button type="button" id="simpan" class="btn btn-primary">Simpan</button>
                            </div>
                        </div>
                    </form>
                </div>
            </section>
            <!-- Main content -->
        </div>


        <footer class="main-footer">
            <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
            All rights reserved.
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b> 3.0.5
            </div>
        </footer>

        <!-- Control Sidebar -->
        <?php $this->load->view('_templates_kasir/control-sidebar') ?>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <?php $this->load->view('_templates_kasir/js'); ?>
    <script type="text/javascript">
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "autoWidth": false,
            });
        });


        $(document).ready(function() {
            $("#simpan").click(function() {
                var order_id = document.getElementById("order_id").value;
                var customer_name = document.getElementById("customer_name").value;
                var region = document.getElementById("region").value;
                var product_name = document.getElementById("product_name").value;
                var date = document.getElementById("date").value;
                var sales = document.getElementById("sales").value;

                $.ajax({
                    url: 'https://api-test.godig1tal.com/order/new_order',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        order_id: order_id,
                        customer_name: customer_name,
                        region: region,
                        product_name: product_name,
                        date: date,
                        sales: sales
                    },
                    success: function(simpan) {
                        console.log(simpan)
                        var order_id = document.getElementById("order_id").value;
                        $("[name='order_id']").val(order_id);
                        $("[name='customer_name']").val('');
                        $("[name='region']").val('');
                        $("[name='product_name']").val('');
                        $("[name='date']").val('');
                        $("[name='sales']").val('');
                    }
                })
            })
        })
    </script>
    <!-- jQuery -->
</body>

</html>