<!DOCTYPE html>
<html>

<head>
    <?php $this->load->view('_templates_kasir/header'); ?>
</head>

<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">

        <!-- Navbar -->
        <?php $this->load->view('_templates_kasir/navbar'); ?>
        <!-- /.navbar -->

        <!-- Main Sidebar Container -->
        <?php $this->load->view('_templates_kasir/sidebar'); ?>

        <!-- Content Wrapper. Contains page content -->
        <div class="content-wrapper">
            <!-- Content Header (Page header) -->
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0 text-dark">Daftar Tanggal Order</h1>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.content-header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Region</label>
                                <select name="region" id="region" class="form-control">
                                    <?php foreach ($region as $reg) : ?>
                                        <option value="<?= $reg ?>"><?= $reg ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Date Start</label>
                                <input type="date" id="date_start" class="form-control">
                                <button type="button" id="cari" class=" btn btn-success mt-2 mb-2 float-right">Cari</button>
                            </div>
                        </div>
                    </div>
                    <table class="table-hover table">
                        <thead>
                            <tr align="center">
                                <th>No</th>
                                <th>Order ID</th>
                                <th>Date</th>
                                <th>Customer Name</th>
                                <th>Region</th>
                                <th>Product Name</th>
                                <th>Sales</th>
                            </tr>
                        </thead>
                        <tbody id="target">

                        </tbody>
                    </table>
                </div>
            </section>
            <!-- Main content -->
        </div>


        <footer class="main-footer">
            <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong>
            All rights reserved.
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b> 3.0.5
            </div>
        </footer>

        <!-- Control Sidebar -->
        <?php $this->load->view('_templates_kasir/control-sidebar') ?>
        <!-- /.control-sidebar -->
    </div>
    <!-- ./wrapper -->

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
    <?php $this->load->view('_templates_kasir/js'); ?>

    <script type="text/javascript">
        $(document).ready(function() {
            $('#cari').click(function() {
                // e.preventDefault()
                var region = document.getElementById('region').value;
                var start = document.getElementById('date_start').value;

                $.ajax({
                    url: 'https://api-test.godig1tal.com/order/range_date_region_order/',
                    type: 'POST',
                    dataType: 'json',
                    data: {
                        region: region,
                        date_start: start
                    },
                    success: function(cari) {
                        var data = cari.data;
                        var no = 1;
                        var baris = '';
                        // console.log(data[0].order_id)
                        // console.log(cari.total)

                        for (var i = 0; i < cari.total; i++) {
                            baris += '<tr>' +
                                '<td>' + no++ + '</td>' +
                                '<td>' + data[i].order_id + '</td>' +
                                '<td>' + data[i].date + '</td>' +
                                '<td>' + data[i].customer_name + '</td>' +
                                '<td>' + data[i].region + '</td>' +
                                '<td>' + data[i].product_name + '</td>' +
                                '<td>' + data[i].sales + '</td>' +
                                '</tr>'
                        }
                        $('#target').html(baris)
                    }
                })
            })
        })
    </script>
    <!-- jQuery -->
</body>

</html>